RECV_DATA_LIST = list()  # 用来存储数据
HANDLE_FLAG = False  # 用来标记是否处理完成