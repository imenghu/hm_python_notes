#主线程死循环，占满cpu
while True:
    pass
