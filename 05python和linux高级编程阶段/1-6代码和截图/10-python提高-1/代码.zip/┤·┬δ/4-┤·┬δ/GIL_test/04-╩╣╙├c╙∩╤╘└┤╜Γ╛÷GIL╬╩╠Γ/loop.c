void DeadLoop()
{
    while(1)
    {
        ;
    }
}   
